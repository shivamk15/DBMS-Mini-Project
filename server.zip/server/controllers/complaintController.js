const Complaint = require('../models/userComplaint')

module.exports.create_complaint = async (req, res) => {
    const data = req.body;
    try {
        const createdComplaint = await Complaint.create(
            { firstName: data.firstName, lastName: data.lastName, email: data.email, city: data.city, address: data.address, contact: data.contact }
        );
        res.status(200).json(createdComplaint);
    } catch (err) {
        res.status(400).json({ err });
    }
}

module.exports.get_complaint = async (req, res) => {
    try {
        const getComplaint = await Complaint.find({});
        res.status(200).json(getComplaint);
    } catch (err) {
        res.status(400).json({ err });
    }
}

