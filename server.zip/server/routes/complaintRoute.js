const { Router } = require('express');
const router = Router();

const complaintController = require('../controllers/complaintController');

router.post('/', complaintController.create_complaint);

router.get('/', complaintController.get_complaint);

module.exports = router;