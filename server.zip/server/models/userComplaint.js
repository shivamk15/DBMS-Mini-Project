const mongoose = require('mongoose');

const userComplaint = mongoose.Schema({
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
    },
    city: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    contact: {
        type: Number,
        required: true
    },
    complaint: {
        type: String,
        default: "Crime"
    },
    created_at: {
        type: Date,
        default: Date.now
    }
})

const Complaint = mongoose.model('complaint', userComplaint);

module.exports = Complaint;